📘 README - MUNDICOL CBT Firestore Import Package

CONTENU DU DOSSIER :
--------------------
1. importQuestions.js  --> Script Node.js pour importer les questions dans Firestore
2. mundicol_cbt_questions_with_feedback_v2.json  --> Fichier JSON avec feedback
3. mundicol_cbt_questions_with_feedback_v2.csv   --> Version Excel (pour usage administratif)
4. README.txt  --> Instructions d'utilisation

ÉTAPES :
--------
1. Placez votre fichier serviceAccountKey.json dans ce dossier.
2. Dans le terminal, exécutez :
   npm install firebase-admin
   node importQuestions.js

3. Résultat : Toutes vos questions seront importées dans Firestore (collection: 'cbt_questions') avec feedback.

Astuce : Utilisez le fichier CSV pour les éditions rapides dans Excel, impressions ou conversion en PDF.

🧠 Par M. Mundi & GPT pour MUNDICOL - Powered by Vision & Rigueur.