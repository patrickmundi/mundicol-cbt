const admin = require("firebase-admin");
const fs = require("fs");

const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();
const questions = JSON.parse(fs.readFileSync("mundicol_cbt_questions_with_feedback_v2.json", "utf8"));

async function importQuestions() {
  const batchSize = 500;
  let batch = db.batch();
  let count = 0;

  for (let i = 0; i < questions.length; i++) {
    const question = questions[i];
    const docRef = db.collection("cbt_questions").doc();
    batch.set(docRef, question);
    count++;

    if (count === batchSize || i === questions.length - 1) {
      await batch.commit();
      console.log(`✅ ${count} questions imported.`);
      batch = db.batch();
      count = 0;
    }
  }

  console.log("🎉 Import completed.");
}

importQuestions().catch(console.error);